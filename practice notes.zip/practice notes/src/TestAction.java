public class TestAction {
 public void aTest(){

TestAction testAction = new TestAction();

DemoBean demoBean = new DemoBean();

demoBean.setId("1");

System.out.println(demoBean.getId());

testAction. bTest(demoBean);

System.out.println(demoBean.getId());

}



public void bTest(DemoBean demoBean){

demoBean.setId("2");

}

    }

