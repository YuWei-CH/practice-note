public class cxy {
    public static void main(String[] args) {
        for (int i = 1; i <= 4; i++) {
            for (int k = 4; i <= k; k--)
                System.out.print(" ");
            for (int a = 1; a <= i; i++)
                System.out.print("*");
            for (int a= 1; a< i; a++)
                System.out.print("*");
              System.out.println();
        }
    }


}
