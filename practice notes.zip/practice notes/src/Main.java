import java.lang.reflect.Array;
import java.util.ArrayList;

public class Main {

      /*  /*for (int i = 1; i <= 4; i++) {
            for (int k = 4; i <= k; k--)
                System.out.print(" ");
            for (int a = 1; a <= i; a++)
                System.out.print("*");
            for (int a = 1; a < i; a++)
                System.out.print("*");
            System.out.println();
        }


        for (int u = 1; u <= 3; u++) {
            for (int g = 1; g <= 3; g++) {
                System.out.print(" ");
                System.out.print("*");
            }
            System.out.println();
        }
        System.out.println("made by peter sun");



        for (int x = 1; x <= 4; x++) {
            for (int y = 4; x <= y; y--)
                System.out.print(" ");
            for (int p = 1; p <= (2 * x - 1); p++)
                System.out.print("*");
            System.out.println();
        }
        for (int z = 1; z <= 4; z++) {
            System.out.println("   ***");
        }*/

   /* private int ID;
    private String name;
    private double price;

    public Main () {
        ID = 0001;
        name = "hello world";
        price = 11.5;

        Main b = new Main();

        public int getID()
        {

        }
        public double setprice(double b);
    }


   for (int l = 5; l >= 0; l--) ;
        {
            for (int a = 9; a >= 1; a = a-2)
                System.out.print(a);
            System.out.println();
            for (int a = 7; a >= 1; a = a-2)
                System.out.print(a);
            System.out.println();
            for (int a = 5; a >= 1; a = a-2)
                System.out.print(a);
            System.out.println();
            for (int a = 3; a >= 1; a = a-2)
                System.out.print(a);
            System.out.println();
            System.out.println("1");



        }
System.out.println();



        public static Date findbirthdate () {






        }

        public static void main(String[] args)
        {
            Date d = findBirthdate();
        }
    }
*/
     /*for (int a=1;a<=4;a++){

         for(int b =4;b>=a;b--)
             System.out.print(" ");
         for (int c =1;c<=a;c++)
             System.out.print("*");
         for (int c =1;c<=a-1;c++)
             System.out.print("*");
         System.out.println();
     }*/

       /* for (int d=1;d<=6;d++){

            for (int e=1;e<=d;e++)
                System.out.print("*");

            for (int f =6;f>=d;f--)
             System.out.print("+");
            System.out.println();
        } */

       /*for (int a = 1; a<=7; a++){
           for (int b = 7 ; b >= a; b--) ;
               System.out.print();
           System.out.println();
       }*/
        /*
       for (int a = 1; a <= 7; a++) {
            for (int b =1; b <= 8-a; b++)
                System.out.print(b);
            System.out.println();
        }*/

       /* for (int a = 1; a <= 7; a++) {
            for (int b =8-a; b >= 1; b--)
                System.out.print(b);
            System.out.println();
        }

          int a = 6%10;
        System.out.print(a);

    }
*/
      /*  int s = 3;
        for (int i = 1; i <= s; i++) {
            for (int k = 1; k <= i; k++)
                System.out.print(" ");
            for (int a = s; a >= i; a--)
                System.out.print("*");
            for (int a = s; a > i; a--)
                System.out.print("*");
            System.out.println();
        }

        for (int i = 1; i <= s; i++) {
            for (int k = s; i <= k; k--)
                System.out.print(" ");
            for (int a = 1; a <= i; a++)
                System.out.print("*");
            for (int a = 1; a < i; a++)
                System.out.print("*");
            System.out.println();
        }

*/

      /* public int sjt (int n,int x){
        int n * 1*10^-(x-1) = int a;
        int n -(a*1*10^(x-1)) = int b;
        int b * 1*10^-(x-2) = int c;
        int b -(c*(1*10^(x-2)= int d;
        int R = d * (10^(x-1)) + c *(10^(x-2)) +a ;
        return R;*/
      /* int g = 1;
       int k = 345;
       int f = k;
       while (f / 10> 10)
      {
          g++ ;
          f = f/10;
      }
       System.out.println(g);;
        while ()*/
        /*int n = 1084398;
        String s = "" + n;
        String string = s;
        String p = "";
        int c = s.length();
        int e = 0;
        while (e < c) {
            p = s.substring(c - e - 1, c - e);
            System.out.print(p);
            e++;
        }*/

     /*  int number = 123456;
        int f = 0;
        while (number != 0) {
            f = f * 10 + (number % 10);
            number = number / 10;
        }
        System.out.print(f);
*/
      /* String s = "HA , HA, I am HA HA";
        String p = "";
         int x = s.indexOf("HA");
       while (s.indexOf("HA") != -1) {
           /* int c = s.length();// c = 18  16 6
            x = s.indexOf("HA"); //x = 1
            p = s.substring(x + 2, c);// p =, HA, I am HA HA  , I am HA HA  HA
           int d = p.indexOf("HA");// d = 3   7 1
            x = d; //x=3   7 x=1
            s = p;  //s=, HA, I am HA HA  s=, I am HA HA s= HA
            c = p.length();//c = 16  12 c=3
            String before = p.substring(0, x-1);// before =,
            //before = before  ;
           System.out.print(before);//,
            String behind = p.substring(x-1,c); // behind =HA, I am HA HA  HA HA
            before = s;//s= HA HA
            //s= before + behind;// s =, HA, I am HA HA
          //System.out.print();*/


       /* int k = 3344;
        int j = 0;
        int o = k;
        while (o > 0) {
            o = o / 10;
            j++;
        }
          int p = k % 10;
        for (int x = j; x > 0; x--) {
            //int p = k % 10;
            p = p * 10 + (k %10);
            // System.out.print(p);
            k = k / 10;

        }
        System.out.print(p);
    */
    //public void remove(String a){

/*
    String a = "HA HA I am HA, HO  h ";
    String h = "HA";
    String before;
    String behind = "";
    String m = "";
    int c;
        while(a.indexOf(h)!=-1)

    {
        int l = a.length();//获得长度
        c = a.indexOf(h);//找到HA的位置
        before = a.substring(0, c);//得到HA之前的
        m = m + before;//储存before
        behind = a.substring(c + 2, l);//得到HA之后的
        a = behind;//使之后等于总
    }
        System.out.print(m +behind);
*/

  /* public  int[] Change(int[] cs) {
        int b = cs[0];
        int a = cs.length - 1;
        for (int n = 0; n < (cs.length) - 1; n++) {
            cs[n] = cs[n + 1];
        }//0-3  1 -4 2-2
        cs[a] = b;
        return cs;
    }

        public static void main(String[] args) {
        int[] test = {2, 3, 4, 5, 8};
        Main s = new Main();
        s.Change(test);
  */
    public  static int[] shiftArray(int[]s,int c)
    {
       return s;
     }
    public static int[][] shiftMatrix(int[][]s,int n)
    {
        for(int i=s.length-1;i>0;i--) {

            shiftArray(s[i], s[i - 1][s[i - 1].length - 1]);
            shiftArray(s[0],n);}
        return s;
    }

    public static ArrayList <Integer> reverse1(ArrayList n) {

        int size = n.size();
        for (int i = 0; i <= (size / 2); i++) {
            Object temp = n.get(i);
            n.set(i, n.get(size - 1));
            n.set(size - 1, temp);
            size--;
        }
        return n;
    }

    public static ArrayList <Integer> reverse2(ArrayList n) {
        ArrayList <Integer> m = new ArrayList <Integer>();
        for (int i = n.size(); i > 0; i--) {
            m.add((Integer) n.get(i - 1));
        }
        return m;
    }

    //1 3 -4 -6 8 9
    public static ArrayList <Integer> NEG1(ArrayList n) {
        for (int a = 0; a < n.size(); a++) {
            if ((int) n.get(a) < 0) {
                n.remove(a);
                a--;
            }
        }
        return n;
    }

    /*  public static ArrayList <Integer> NEG2(ArrayList n) {
                      int i = 0;
                      int length = n.size();
          for(int a = 0;a<length;a++) {
                  if ((int) n.get(i) > 0) {
                      n.set(i, n.get(a));
                      i++;
                  }
              }
          return n;
      }
  */
    public static void swap(int[][] array) {

        for (int i = 0; i < (array.length) / 2; i++) {
            int[] temp = array[i];
            array[i] = array[array.length - i - 1];
            array[array.length - i - 1] = temp;
        }

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static ArrayList <Integer> reverse3(ArrayList <Integer> n) {
        ArrayList <Integer> temp = new ArrayList <Integer>();
        while (n.size() > 0) {

            temp.add(n.get(n.size() - 1));
            n.remove(n.size() - 1);

        }
        return temp;
    }


    public static class TEST {

        public String removetest(String n, String h) {
            String before;
            String behind = "";
            String m = "";
            int c;
            while (n.indexOf(h) != -1) {
                int l = n.length();//获得长度
                c = n.indexOf(h);//找到HA的位置
                before = n.substring(0, c);//得到HA之前的
                m = m + before;//储存before
                behind = n.substring(c + h.length(), l);//得到HA之后的
                n = behind;//使之后等于总
            }
            String end = m + behind;

            return end;
        }


        public static void insertarray(int[] m, int n) {
            int[] newarray = new int[m.length];
            newarray[0] = n;
            for (int i = 0; i < newarray.length - 1; i++) {
                newarray[i + 1] = m[i];

            }
            for (int x : newarray) {
                System.out.print(x);
            }

        }

        public static void insertmat(int[][] m, int z) {
            int l = m[0].length;
            for (int i = l; i > 0; i--) {
                insertarray(m[i], m[i - 1][m[i - 1].length - 1]);
            }
            insertarray(m[0], z);
        }

        public void reversetest1(int number) {
            int f = 0;
            while (number != 0) {
                f = f * 10 + (number % 10);
                number = number / 10;
            }
            System.out.print(f);

        }

            public  static void reversetest2(int n) {
            if (n%10!=0) {
                System.out.print(n % 10);
               n=n/10;
                reversetest2(n);
            }
        }
    }

        public static void main(String[] args) {

            ArrayList <Integer> n = new ArrayList <Integer>();
            n.add(1);
            n.add(3);
            n.add(-4);
            n.add(-6);
            n.add(8);
            n.add(9);
           /* System.out.print(Main.reverse1(n));
            System.out.print(Main.reverse2(n));
            System.out.print(Main.reverse3(n));
            System.out.print(Main.NEG1(n));

            int[][] array = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

            Main.swap(array);
            //int[] m = new int[]{1,2,3,4,5};
            //TEST.insertarray(m,6);
            TEST.reversetest2(987654321);
            // TEST a = new TEST();
            //System.out.print(a.removetest("HA HA I am H HA", "HA"));

            //  System.out.print(a.reversetest2(1234, 0));*/
        }


    }














   public static void main(String[] args) {
        /*ArrayList<Integer> zzy =new ArrayList<Integer>();
        for (int j=0; j<6; j++){
            zzy.add(j);
        }
        System.out.print(reverse(zzy));*/

        int i = 1;

        for (int i = 0; i<5;i++){

            System.out.print(i);
   }
        while (i>5){

            i = i+3;
            i--;

        }


}
}













